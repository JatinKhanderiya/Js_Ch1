let age=20;
let name="Jatin";

// let aboutMe="My Name Is" + name +" My Age Is"+age;

// console.log(aboutMe);
let aboutMe=`My Name Is ${name} My Age IS ${age}`;
console.log(aboutMe);
