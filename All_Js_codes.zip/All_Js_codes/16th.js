// (And &&), (Or ||) Operators

let marks=96;
let rank=1;

if(marks>=90 && rank>2)
{
    console.log("You Got Top");
}
else
{
    console.log("You Got Another Rank");
}
// Or Operator

let mark=96;
let percentage=96;

if(mark>=90 || rank>90)
{
    console.log("You Got 1st Rank");
}
else
{
    console.log("Do HardWork For Achivement");
}
