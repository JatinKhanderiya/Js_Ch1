// Premetive Vs Reference Data Type :

// Premetive Data Type:         If We Change Value In Num1 But Value Is Not Change In Num2

let num1=8;                     //  If We Change Value In Num1 But Value Is Not Change In Num2
let num2=num1;
num1++;
console.log("Number 1 is:"+num1);
console.log("Number 2 is:"+num2);


// Reference Data Type :

array1=["Jatin","Mohit"];
array2=array1;
console.log("Array1 Is :"+array1);
console.log("Array2 Is :"+array2);

array1.push("Aman");
console.log("Array1 Is :"+array1);
console.log("Array2 Is :"+array2);

