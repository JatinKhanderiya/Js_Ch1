// trim()   Use To Remove Spaces From Value
// toUpperCase() For Convert UpperClass 
// toLowerCase() For Convert LowerClsass
// slice()  Cut The Word

// let firstName = "     Jatin    ";

// console.log(firstName.length);
// firstName = firstName.trim(); // "Jatin"
// console.log(firstName)
// console.log(firstName.length);
// firstName = firstName.toUpperCase();
// firstName = firstName.toLowerCase();
// console.log(firstName);

// start index 
// end index

let name="Jatin";
// let newString = name.slice(1); // atin
let newString=name.slice(0,4);
console.log(newString);

