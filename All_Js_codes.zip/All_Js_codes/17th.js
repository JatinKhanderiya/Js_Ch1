// Nested If Condition  :


let age=18;
if(age>18)
{
    console.log("You Are Eligeble For Licence");
}
else
{
    if(age<18)
    {
        console.log("You Are Not Eligeble For Licence");
    }
    else(age=18)
    {
        console.log("Wait For Only Some Months");
    }

}