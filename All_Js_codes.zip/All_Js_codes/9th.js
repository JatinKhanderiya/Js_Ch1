// string concatenation 

let fName="Jatin";
let lName="Khanderiya";
let fullName= fName +" "+lName;
console.log(fullName);
