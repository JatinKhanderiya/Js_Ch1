// Object Inside Array :
// Useful Topic

const games=[
    {name:"Cricket",type:"Outdoor"},
    {name:"FootBall",type:"Outdoor"},
    {name:"SubwaySurfs",type:"Indoor"},
]
// console.log(games);

for(let j of games){
    console.log(j);
    console.log(j.name);
}