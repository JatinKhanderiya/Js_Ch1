// simple Basic Hello World Function

console.log("Hllw Welcome To Sky 9");