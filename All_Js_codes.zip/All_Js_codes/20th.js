// While Loop :

let i=0;
while(i<=3){
    console.log(i);
    i++;
}

// Do While Loop:
console.log("Do While Loop");

let j=0;
do{
    console.log(j);
    j++;
}
while(j<=9);

// For Loop:
console.log("For Loop");


let total=0;
let num=10;

for(let i=1;i<=num;i++){
    total=total+num;
}
console.log(total);

