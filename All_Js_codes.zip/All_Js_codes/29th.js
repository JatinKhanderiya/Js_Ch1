// Array Destructing :

const array1=["modi","shah","kalam"];
let value1=array1[0];
let value2=array1[1];
let value3=array1[2];
console.log(value1,value2,value3);

// Simple Destructing Method 
const array2=["modi","shah","kalam"];
// let [price1, price2, price3]=array1;

let [price1,,price3]=array1;        //So We Also Take One Empty Space And Coma To Skip The Value
console.log(price1,price3);
// console.log(price1,price2,price3);


// New Method Only Take 3dot To Create New Array :

// array destructuring 
const myArray = ["value1", "value2", "value3","value4"];

let [myvar1, myvar2, ...myNewArray] = myArray;       //myNewArray Is Created Here By Doing 3 Dots 
console.log("value of myvar1", myvar1);
console.log("value of myvar2", myvar2);
console.log(myNewArray);
