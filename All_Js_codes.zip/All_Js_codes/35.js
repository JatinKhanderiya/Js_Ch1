// object destructuring

const band = {
    bandName: "led zepplin",
    famousSong: "stairway to heaven",
    year: 1968,
    anotherFamousSong: "kashmir",
  };
  
//   let { bandName, famousSong} = band;
//   let { bandName:var1, famousSong:var2 }=band;      //Now We Chnage The Name Of Keys bandname=var..
  let { bandName, famousSong, ...restProps } = band;        //Last 2 Values Ne Print Karavva Mate
  
  console.log(bandName);
  console.log(famousSong);
  console.log(restProps);