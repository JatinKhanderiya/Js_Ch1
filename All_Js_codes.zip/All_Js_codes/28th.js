// For Of Loop In Array :       Provide The Value Of Main Array...

const fruits=["Apple","Bananna","Kiwi"];
for(let basket of fruits){
    console.log(basket);
}


// For Of loop:     Provide The Index Of Main Array...

const garrage=["Kia","RolsRoys","Odi"];

for(let car in garrage){
    console.log(car);       //Print Only Indexes Of Cars

}