// While Loop in Array :

let bikes=["Ninja","Ktm","Merce"];
let i=0;
while(i<bikes.length){
    console.log(bikes[i]);
    i++;
}