// hoisting 

hello();

function hello(){
    console.log("hello world");
}

// console.log(hello1);
const hello1 = "hello world";
console.log(hello1);