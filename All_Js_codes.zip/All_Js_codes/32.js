// Iterate Object By Using For In And Object.Keys::

// For In  Loop
const person = {
    name: "Jatin",
    age: 20,
    hobbies: ["Reading","English","Computer Knowledge"]
}

for(let j in person){
    console.log(`${j}:${person[j]}`);    //$Method 
    console.log(j,":",person[j]);           //Simple Method
}

// By Using Object. Method:

// console.log(typeof (Object.keys(person)));
// const val = Array.isArray((Object.keys(person)));
// console.log(val);

for(let key of Object.keys(person)){
    console.log(person[key]);
}

