// array push pop 

// array shift unshift 

let fruits = ["apple", "mango", "grapes"];
console.log(fruits);

// push         Add Element In Ending:
fruits.push("banana");
console.log(fruits);

// pop          Remove Element From Ending And Also Store It:
let poppedFruit = fruits.pop();
console.log(fruits);
console.log("popped fruits is", poppedFruit);

// unshift       Add Element In Starting:
fruits.unshift("banana");
fruits.unshift("myfruit");
console.log(fruits);

// shift         Remove Element From Ending And Also Store It:
let removedFruit = fruits.shift();
console.log(fruits);
console.log("removed fruits is ", removedFruit);