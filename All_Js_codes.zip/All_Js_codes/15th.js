// Ternary/Conditional Operator

let marks=45;
let rank;

if(marks>=33)
{
    rank="You Are Pass";
}
else
{
    rank="Better luck For Next Time..";
}
console.log(rank);

// Ternary/Conditional Operator Method

let marks1=23;
let rank1=marks1>33? "pass":"fail";
console.log(rank1);
