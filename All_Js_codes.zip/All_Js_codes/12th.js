// Comparison Operator With Boolean Output 

let num1=20;
let num2=80;

console.log(num1<num2);
console.log(num1>num2);
console.log(num1<=num2);
console.log(num1>=num2);

console.log(num1==num2);    //Chek Only Values Of Both
console.log(num1===num2);      //Chek Value With Data Type

console.log("<br/><br/>");
// != && !== Not Equal To With Not Equalto

let value1="30";
let value2= 200;

console.log(value1!==value2);       //Chek Only DataType
console.log(value1!=value2);        //Chek Only value

