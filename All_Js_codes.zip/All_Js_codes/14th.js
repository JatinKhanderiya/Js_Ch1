// if else condition 

let age = 17;

if(age>=18){
    document.write("You Are Eligeble");
}else {
    document.write("You Are Not Eligeble");
}

document.write("<br/><br/>");

let num = 13;

if(num%2===0){
    document.write("even");
}else{
    document.write("odd");
}
document.write("<br/><br/>");

// falsy values 

// false
// ""
// null 
// undefined
// 0

// truthy 
// "abc"
// 1, -1
document.write("<br/><br/>");

let firstName= 0;    //False Values: "",false,null.undefined

if(firstName){
    document.write(firstName);
}else{
    document.write("firstName is kinda empty");
}