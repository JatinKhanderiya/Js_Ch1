// variable Programme :-
// intro to variables

// variables can store some information
// we can use that information later
// we can change that information later

"use strict";

// Declare A Variable
var a="Jatin";

// Use A Variable
console.log(a);

// Change The Value Of Variable

var a="Khanderiya";
console.log(a);


