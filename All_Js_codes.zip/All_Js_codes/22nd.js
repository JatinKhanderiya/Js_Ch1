// Array ::

let bikes=["harley","Ninja","Mercedes"];
console.log(bikes);
console.log(bikes[2]);

console.log(typeof bikes);   //Array Is From REference Means One Type Of Object
console.log(Array.isArray(bikes));     //TO Clearly Chek Of Array Or Not
