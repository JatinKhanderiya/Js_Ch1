// find method 

const myArray = ["Hello", "catt", "dog", "lion"];

function isLength3(string){
    return string.length === 3;
}

const ans = myArray.find((string)=>string.length===3);      //Shwo Arrays Of 3 Length
console.log(ans);

const users = [
    {userId : 1, userName: "Jatin"},
    {userId : 2, userName: "Yash"},
    {userId : 3, userName: "Aman"},
    {userId : 4, userName: "Chirag"},
    {userId : 5, userName: "aaditya"},
];

const myUser = users.find((user)=>user.userId===3);
console.log(myUser);