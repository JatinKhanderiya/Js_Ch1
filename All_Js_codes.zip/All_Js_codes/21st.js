// Break And Continue Statements 

let i=0;
for(i=0;i<10;i++){
    if(i==4){
        continue;
    }
    console.log(i);
}

let j=0;
for(j=0;j<10;j++){
    if(j==4){
        break;
    }
    console.log(j);
}