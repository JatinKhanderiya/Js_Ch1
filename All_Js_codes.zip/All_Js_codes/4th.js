// Declare With Let Keyword

// let keyword 
// declare variable with let keyword 

let firstName = "Jatin";
firstName = "Khanderiya";
console.log(firstName);


// block scope vs funtion scope (covered later in this video)