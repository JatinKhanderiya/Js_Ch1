// typeof()_Operators
// Convert Number To String
// Convert String To Number

// data types (primitive data types)
// string "harhit"
// number 2, 4, 5.6 
// booleans 
// undefined
// null 
// BigInt
// Symbol

let id=22;
console.log(id);
console.log(typeof id);

id=id+"";
console.log(typeof id);

let name="Jatin";
name=+"Jatin";
console.log(typeof name);

// 2nd Way To Covert 

id=String(22);
console.log(typeof id);
