// block scope vs function scope 
// ::::

// let and const are block scope

// var is function scope 

if(true){
    var firstName = "JATIN";        //var Ni Jagyae Let Lidhu Hot To Acess Na That 
    console.log(firstName);
}

console.log(firstName);

function myApp(){
    if(true){
        var firstName1 = "Jatin";
        console.log(firstName1);
    }

    if(true){
        console.log(firstName1);
    }
    console.log(firstName);
}

myApp();