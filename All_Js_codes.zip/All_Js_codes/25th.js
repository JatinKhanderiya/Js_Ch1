// For Loop In Array:
let array1=["Dell","Lenovo","Asus"];
let array2=[];
for(let i=0;i<array1.length;i++)
{
    array2.push(array1[i].toUpperCase());

}
console.log(array2);


