// undefined Data Type
// Null Deta Type
// BigInt Data Type

// undefined

let myName;
console.log(typeof myName);

let age=null;
console.log(typeof age);  //Output come Object One Type Of Bug In  Js

let myAge=BigInt(5944444646464);
let myAge2=6644644n

console.log(typeof myAge);
console.log(typeof myAge2);
