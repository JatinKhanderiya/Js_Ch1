// Function Inside The Function:

function jatin(){

    let  aman =() => {
        console.log("Hello From Aman");
    }
    
    console.log("Hello From Jatin");
    aman();
}
jatin();

