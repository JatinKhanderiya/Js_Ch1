// arrow functions


// const singHappyBirthday = function(){
//     console.log("happy birthday to you ......");
// }

const singHappyBirthday = () => {
    console.log("happy birthday to you ......");
}

singHappyBirthday();

const sumThreeNumbers = (number1, number2, number3) => {
    return number1 + number2 + number3;
}

const ans = sumThreeNumbers(2,3,4);
console.log(ans);

// const isEven = function(number){
//     return number % 2 === 0;
// }


// const isEven = number => {
//     return number % 2 === 0;
// }
const isEven = number => number%2===0;      //This Also One Tyep To Write Functoin And Remove Return 


console.log(isEven(4));

// New Function:

const firstChar = anyString => anyString[0];

console.log(firstChar("harshit"));
 

const findTarget = (array, target) => {
    for(let i = 0; i<array.length; i++){
        if(array[i]===target){
            return 1;
        }
    }
    return -1;
}
const myArray = [1,3,8,90]
const ans1 = findTarget(myArray, 3);
console.log(ans);