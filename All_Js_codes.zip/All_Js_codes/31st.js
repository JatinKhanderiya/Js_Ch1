// difference between dot and bracket notaion:

const key = "email";
const person = {
    name: "Jatin",
    age: 20,
    "person hobbies": ["guitar", "sleeping", "listening music"]

}
// console.log(person.person hobbies);     //Do No Acess With Space Keys By Using Dot 

console.log(person["person hobbies"]);         // We Acess With Space Key By Using Brakets 
person[key] = "jatinkhanderiya27@gmail.com";        //Access Key Email 
console.log(person);
