// string Indexing Programme:

let name=("Jatin");
//  J A T I N 
//  0 1 2 3 4

console.log(name[0]);

console.log(name.length);
console.log(name[name.length-1]);
