// Spred Operator:

let array1=[4,5,6];
let array2=[7,8,9];

const myNewArray=[...array1,...array2];
console.log(myNewArray);

const newArray=[..."abc"];
console.log(newArray);

// Spred Operator In Obj:

const obj1 = {
    key1: "value1",
    key2: "value2",
  };
  const obj2 = {
    key1: "valueUnique",
    key3: "value3",
    key4: "value4",
  };
  
  const newObject = { ...obj2, ...obj1};                     //2 Keys Are There So Last One Will Print 
  const newObject1 = { ...obj2, ...obj1,key69:"value 96"};           //Add New Value 
      
  const newObject2 = { ...["item1", "item2"] };
  const newObject3 = { ..."abcdefghijklmnopqrstuvwxyz" };
  console.log(newObject);
  console.log(newObject1);
  console.log(newObject2);
  console.log(newObject3);